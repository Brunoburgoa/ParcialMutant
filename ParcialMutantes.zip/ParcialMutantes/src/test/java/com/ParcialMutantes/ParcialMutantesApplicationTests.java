package com.ParcialMutantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialMutantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
